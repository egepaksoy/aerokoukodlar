import time
import sys
import threading
from math import cos, radians

sys.path.append('../pymavlink_custom')
from pymavlink_custom import Vehicle
from mqtt_controller import magnet_control, rotate_servo, cleanup


def failsafe(vehicle):
    def failsafe_drone_id(vehicle, drone_id):
        print(f"{drone_id}>> Failsafe alıyor")
        vehicle.set_mode(mode="RTL", drone_id=drone_id)
    threads = []
    for d_id in vehicle.drone_ids:
        t = threading.Thread(target=failsafe_drone_id, args=(vehicle, d_id))
        t.start()
        threads.append(t)
    for t in threads:
        t.join()
    print(f"Dronlar {vehicle.drone_ids} Failsafe aldı")


def main():
    if len(sys.argv) != 3:
        print("Usage: python main.py <connection_string> <drone_id>")
        sys.exit(1)

    magnet_control(True, True)
    print("mıknatıslar açık")

    vehicle = Vehicle(sys.argv[1])
    DRONE_ID = int(sys.argv[2])
    ALT = 5

    loc1 = (40.7121252, 30.0245713, ALT)  # Kalkış ve hedef konum
    meters_forward = 5
    delta_lon = meters_forward / (111000 * cos(radians(loc1[0])))
    loc2 = (loc1[0], loc1[1] + delta_lon, ALT)  # Opsiyonel başka bir hedef

    try:        
      
        vehicle.set_mode("GUIDED", drone_id=DRONE_ID)
       
        rotate_servo(0)
        print("servo duruyor")

        vehicle.arm_disarm(True, drone_id=DRONE_ID)

        vehicle.takeoff(ALT, drone_id=DRONE_ID)
        print(f"{DRONE_ID}>> Kalkış tamamlandı")

        vehicle.send_all_waypoints(drone_id=DRONE_ID, wp_list=[loc1])
        vehicle.set_mode("AUTO", drone_id=DRONE_ID)

        while not vehicle.on_location(loc=loc1, seq=1, sapma=1, drone_id=DRONE_ID):
            time.sleep(0.5)
        print(f"{DRONE_ID}>> Hedef konuma ulaşıldı")

        magnet_control(True, False)
        print("mıknatıs2 kapatıldı")
        time.sleep(2)

        vehicle.set_mode("GUIDED", drone_id=DRONE_ID)
        vehicle.goto_location(loc2, drone_id=DRONE_ID)

        while not vehicle.on_location(loc=loc2, seq=2, sapma=1, drone_id=DRONE_ID):
            time.sleep(0.5)
        print(f"{DRONE_ID}>> İkinci hedef konuma ulaşıldı")

        magnet_control(False, False)
        print("mıknatıs1 kapatıldı")
        time.sleep(2)

        # 🚁 LAND başlat
        vehicle.set_mode("LAND", drone_id=DRONE_ID)
        print(f"{DRONE_ID}>> LAND başlatıldı")

        print(">> Drone iniş yapıyor, görev tamamlanmak üzere...")

    except KeyboardInterrupt:
        print("Klavye ile çıkış yapıldı")
        failsafe(vehicle)

    except Exception as e:
        print("Hata:", e)
        failsafe(vehicle)

    finally:
        vehicle.vehicle.close()
        cleanup()
        print(">> GPIO temizlendi, bağlantı kapatıldı")


if __name__ == "__main__":
    main()
